Does not work with latest version of node. Tested stable on Node 14.

How to run:

- `npm install`
- `npm start`
- Open `localhost:3000`