This Model 3D format was designed to address all of the
shortcomings of the existing current formats, so that it can became a truely universal 3D model container and ease all developer's
and model designer's minds, consistently parsed by all software while being easy on network traffic at the same time: