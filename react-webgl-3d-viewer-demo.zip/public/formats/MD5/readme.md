The MD5 model format comes from id Software's Doom 3 first person shooter, released in august 2004. The mesh data and animation data are separated in distinct files. These are ASCII files and are human readable. Here are some generalities about the MD5 format:
- Model's geometric data are stored in *.md5mesh files;
- Animations are stored in *.md5anim files;
- Supports Skeletal Animation;
- Supports Vertex Skinning;
- Uses quaternions for orientation.
